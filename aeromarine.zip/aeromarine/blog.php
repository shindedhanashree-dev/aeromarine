<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Agrovia - Agriculture Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex flex-column align-items-center justify-content-center">
        <span class="spinner-border text-primary mb-2" role="status" style="width: 3rem; height: 3rem;"></span>
        Loading...
    </div>
    <!-- Spinner End -->


    <!-- Header Start -->
     <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg navbar-dark px-lg-5">
            <a href="index.html" class="navbar-brand ms-4 ms-lg-0">
                <h1 class="display-6 text-primary mb-0"><i class="fa fa-seedling"></i>Agrovia</h1>
            </a>
            <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-auto p-4 p-lg-0">
                    <a href="index.html" class="nav-item nav-link">Home</a>
                    <a href="about.html" class="nav-item nav-link">About</a>
                    <a href="service.html" class="nav-item nav-link">Services</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle active" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu overflow-hidden border-top border-5 border-dark mt-2">
                            <a href="blog.html" class="dropdown-item active">Blog</a>
                            <a href="feature.html" class="dropdown-item">Features</a>
                            <a href="team.html" class="dropdown-item">Our Team</a>
                            <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                            <a href="404.html" class="dropdown-item">404 Page</a>
                        </div>
                    </div>
                    <a href="contact.html" class="nav-item nav-link">Contact</a>
                </div>
                <a class="btn btn-primary btn-custom rounded-pill d-none d-lg-flex" href="https://htmlcodex.com/downloading/?item=4081">Pro Version</a>
            </div>
        </nav>

        <div class="page-header position-relative">
            <img class="w-100" src="img/carousel-2.jpg" alt="Image">
            <div class="page-header-caption">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-10 col-md-8 text-center">
                        <h1 class="display-1 text-white animated slideInDown mb-4">Blog</h1>
                        <nav aria-label="breadcrumb animated slideInDown">
                            <ol class="breadcrumb justify-content-center mb-0">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                                <li class="breadcrumb-item text-white">Blog</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
     </div>
    <!-- Header End -->


    <!-- Blog Start -->
    <div class="container-fluid bg-light py-5">
        <div class="container py-5">
            <div class="section-title wow fadeIn" data-wow-delay="0.1s">
                <h5 class="mb-3"><i class="fa fa-leaf text-primary me-2"></i>Blog Posts</h5>
                <h1 class="display-5 mb-5">Latest From the Farm</h1>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                    <div class="blog-item position-relative overflow-hidden bg-white rounded h-100 p-4">
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <span>01 Jan 2045</span>
                            <hr class="mx-4">
                            <span>Design</span>
                        </div>
                        <a href="" class="h4 lh-base d-block text-center mb-4">How Sustainable Farming Protects Future</a>
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid rounded w-100" src="img/blog-1.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.3s">
                    <div class="blog-item position-relative overflow-hidden bg-white rounded h-100 p-4">
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <span>01 Jan 2045</span>
                            <hr class="mx-4">
                            <span>Design</span>
                        </div>
                        <a href="" class="h4 lh-base d-block text-center mb-4">Essential Tips for Growing Healthy Crops</a>
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid rounded w-100" src="img/blog-2.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                    <div class="blog-item position-relative overflow-hidden bg-white rounded h-100 p-4">
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <span>01 Jan 2045</span>
                            <hr class="mx-4">
                            <span>Design</span>
                        </div>
                        <a href="" class="h4 lh-base d-block text-center mb-4">Best Practices for Successful Organic Farming</a>
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid rounded w-100" src="img/blog-3.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Blog End -->
        

    <!-- Newsletter Start -->
    <div class="container-fluid newsletter bg-dark py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-7 text-center wow fadeIn" data-wow-delay="0.5s">
                    <h1 class="display-5 text-white mb-4">Subscribe the Newsletter</h1>
                    <div class="position-relative w-100 mb-2">
                        <input class="form-control rounded-pill border-0 w-100 ps-4 pe-5" type="text"
                            placeholder="Enter Your Email" style="height: 60px;">
                        <button type="button" class="btn btn-lg-square shadow-none position-absolute top-0 end-0 mt-1 me-2"><i
                                class="fa fa-paper-plane text-primary fs-4"></i></button>
                    </div>
                    <p class="text-light mb-0">Don't worry, we won't spam you with emails.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Newsletter End -->


    <!-- Footer Start -->
    <div class="container-fluid footer bg-dark text-light py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Our Office</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>123 Street, New York, USA</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+012 345 67890</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@example.com</p>
                    <div class="d-flex pt-3">
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-x-twitter"></i></a>
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Business Hours</h4>
                    <h6 class="text-white mb-1">Monday - Friday</h6>
                    <p>09:00 am - 07:00 pm</p>
                    <h6 class="text-white mb-1">Saturday</h6>
                    <p>09:00 am - 12:00 pm</p>
                    <h6 class="text-white mb-1">Sunday Closed</h6>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Quick Links</h4>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                    <a class="btn btn-link" href="">Our Services</a>
                    <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">Support</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Gallery</h4>
                    <div class="row g-2">
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service-1.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service-2.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service-3.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service-4.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service-5.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service-6.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Copyright Start -->
    <div class="container-fluid copyright bg-dark text-light py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; <a class="fw-semi-bold" href="#">Your Site Name</a>, All Right Reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <!--/*** The author’s attribution link below must remain intact on your website. ***/-->
                    <!--/*** If you wish to remove this credit link, please purchase the Pro Version from https://htmlcodex.com/downloading/?item=4081 ***/-->
                    Designed By <a class="fw-semi-bold" href="https://htmlcodex.com">HTML Codex</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright Start -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>