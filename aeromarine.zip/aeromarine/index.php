<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Aeromarine Import Exports</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <?php include("components/indexComponents/head.php"); ?>

</head>

<body>
    <div class="container-fluid p-0">

        <?php include("components/indexComponents/navbar.php"); ?>

        <?php include("components/indexComponents/banner.php"); ?>
    </div>

    <!-- About Start -->

    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row g-5">

                <div class="col-xl-9">
                    <h5 class="mb-3">
                        <i class="fa fa-leaf text-primary me-2"></i>
                        About Aeromarine Import Exports
                    </h5>

                    <h2 class="display-5 mb-4">
                        Indian Agricultural Products Exporter
                    </h2>

                    <div class="row g-5">
                        <div class="col-lg-4">
                            <img class="img-fluid rounded w-100 h-100" style="object-fit: cover;" src="img/about-1.jpg"
                                alt="about1">
                        </div>

                        <div class="col-lg-8">
                            <h4 class="lh-base mb-4">
                                Quality Indian Spices, Dehydrated Ingredients
                                and Natural Agro Products
                            </h4>

                            <p class="mb-4">
                                Aeromarine Import Exports is an India-based
                                agricultural products exporter specializing in
                                Indian spices, dehydrated food ingredients,
                                natural sweeteners and functional food ingredients
                                for international markets. We connect global
                                importers, wholesalers and food manufacturers
                                with products tailored to their sourcing needs.
                            </p>

                            <p class="mb-4">
                                Our product range includes turmeric fingers,
                                turmeric powder, red chilli powder, garlic powder,
                                onion powder, psyllium husk, potato powder,
                                jaggery cubes and jaggery powder. We support
                                product sourcing, packaging coordination and
                                export documentation to simplify global
                                agricultural trade.
                            </p>

                            <div class="about-items-2 bg-light rounded">
                                <div class="row g-0">

                                    <div class="col-md-6">
                                        <div class="h-100 p-4 border-end">
                                            <i class="fa fa-seedling fa-3x text-primary mb-3"></i>
                                            <h5>Quality-Focused Sourcing</h5>
                                            <p class="mb-0">
                                                Agricultural products selected
                                                according to buyer specifications
                                                and quality requirements.
                                            </p>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="h-100 p-4">
                                            <i class="fa fa-globe fa-3x text-primary mb-3"></i>
                                            <h5>Global Export Solutions</h5>
                                            <p class="mb-0">
                                                Reliable B2B sourcing support,
                                                packaging coordination and
                                                export documentation assistance.
                                            </p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 d-none d-xl-block">
                    <img class="img-fluid rounded w-100 h-100" style="object-fit: cover;" src="img/about-2.jpg"
                        alt="about2 ">
                </div>

            </div>
        </div>
    </div>

    <!-- About End -->


    <!-- Service Start -->

    <div class="container-fluid bg-light py-5">
        <div class="container py-5">

            <!-- Section Heading -->
            <div class="section-title wow fadeIn" data-wow-delay="0.1s">
                <h5 class="mb-3">
                    <i class="fa fa-leaf text-primary me-2"></i>
                    Our Export Services
                </h5>
                <h2 class="display-5 mb-5">
                    Agricultural Export Solutions for Global Buyers
                </h2>
            </div>

            <div class="row g-4">

                <!-- Service 01 -->
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.1s">
                    <div class="service-item position-relative overflow-hidden bg-white rounded p-4 h-100">

                        <div class="position-relative overflow-hidden rounded mb-4">
                            <img class="img-fluid w-100" src="img/service1.jpg" alt="service1">
                            <div class="position-absolute start-0 top-0 m-4 btn-lg-square rounded-circle">
                                <h4 class="text-white mb-0">01</h4>
                            </div>
                        </div>

                        <h4 class="mb-3">Agricultural Product Exports</h4>
                        <p class="mb-4">
                            We supply a diverse range of Indian agro products to international
                            buyers, wholesalers, distributors and food manufacturers.
                        </p>
                        <a class="btn btn-primary btn-custom rounded-pill" href="products.php">
                            Explore Products
                        </a>

                    </div>
                </div>

                <!-- Service 02 -->
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.1s">
                    <div class="service-item position-relative overflow-hidden bg-white rounded p-4 h-100">

                        <div class="position-relative overflow-hidden rounded mb-4">
                            <img class="img-fluid w-100" src="img/service2.jpg" alt="service2">
                            <div class="position-absolute start-0 top-0 m-4 btn-lg-square rounded-circle">
                                <h4 class="text-white mb-0">02</h4>
                            </div>
                        </div>

                        <h4 class="mb-3">Quality & Specification Coordination</h4>
                        <p class="mb-4">
                            We coordinate product specifications, quality parameters and
                            relevant inspection requirements according to buyer needs.
                        </p>
                        <a class="btn btn-primary btn-custom rounded-pill" href="contact.php">
                            Learn More
                        </a>
                    </div>
                </div>

                <!-- Service 03 -->
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.3s">
                    <div class="service-item position-relative overflow-hidden bg-white rounded p-4 h-100">

                        <div class="position-relative overflow-hidden rounded mb-4">
                            <img class="img-fluid w-100" src="img/service3.jpg" alt="service3">
                            <div class="position-absolute start-0 top-0 m-4 btn-lg-square rounded-circle">
                                <h4 class="text-white mb-0">03</h4>
                            </div>
                        </div>

                        <h4 class="mb-3">Customized Export Packaging</h4>
                        <p class="mb-4">
                            Explore bulk and retail packaging options tailored to product
                            requirements, order quantities and buyer preferences, ensuring
                            convenient handling, storage and transportation.
                        </p>
                        <a class="btn btn-primary btn-custom rounded-pill" href="contact.php">
                            Enquire Now
                        </a>
                    </div>
                </div>

                <!-- Service 04 -->
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.5s">
                    <div class="service-item position-relative overflow-hidden bg-white rounded p-4 h-100">

                        <div class="position-relative overflow-hidden rounded mb-4">
                            <img class="img-fluid w-100" src="img/service4.jpg" alt="service4">
                            <div class="position-absolute start-0 top-0 m-4 btn-lg-square rounded-circle">
                                <h4 class="text-white mb-0">04</h4>
                            </div>
                        </div>

                        <h4 class="mb-3">Export Logistics & Documentation</h4>
                        <p class="mb-4">
                            We coordinate export documentation and shipping arrangements
                            to support international agricultural product consignments.
                        </p>
                        <a class="btn btn-primary btn-custom rounded-pill" href="contact.php">
                            Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Service End -->


    <!-- Features Start -->

    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row g-5">

                <div class="col-xl-9">
                    <div class="row g-5">

                        <div class="col-lg-4">
                            <div class="position-relative h-100 wow fadeIn" data-wow-delay="0.3s">
                                <img class="img-fluid rounded w-100 h-100" style="object-fit: cover;"
                                    src="img/feature1.jpg" alt="feature1">
                            </div>
                        </div>

                        <div class="col-lg-8">
                            <div class="wow fadeIn" data-wow-delay="0.1s">
                                <h5 class="mb-3">
                                    <i class="fa fa-leaf text-primary me-2"></i>
                                    Why Choose Us
                                </h5>

                                <h1 class="display-5 mb-4">
                                    Why Choose Aeromarine Import Exports?
                                </h1>
                            </div>

                            <p class="mb-4 wow fadeIn" data-wow-delay="0.2s">
                                Aeromarine Import Exports supplies Indian spices,
                                dehydrated ingredients, psyllium husk, and natural
                                sweeteners to global markets. We focus on direct
                                sourcing, quality checks, customized specifications,
                                and dependable export coordination.
                            </p>

                            <div class="row g-4">

                                <div class="col-md-6 wow fadeIn" data-wow-delay="0.3s">
                                    <div class="d-flex align-items-center bg-light rounded h-100 p-4">
                                        <div class="flex-shrink-0 btn-lg-square rounded bg-primary text-dark me-3">
                                            <i class="fa fa-handshake fs-4"></i>
                                        </div>
                                        <h5 class="lh-base mb-0">
                                            Direct Farm Sourcing
                                        </h5>
                                    </div>
                                </div>

                                <div class="col-md-6 wow fadeIn" data-wow-delay="0.4s">
                                    <div class="d-flex align-items-center bg-light rounded h-100 p-4">
                                        <div class="flex-shrink-0 btn-lg-square rounded bg-primary text-dark me-3">
                                            <i class="fa fa-shield-halved fs-4"></i>
                                        </div>
                                        <h5 class="lh-base mb-0">
                                            Quality Assurance
                                        </h5>
                                    </div>
                                </div>

                                <div class="col-md-6 wow fadeIn" data-wow-delay="0.5s">
                                    <div class="d-flex align-items-center bg-light rounded h-100 p-4">
                                        <div class="flex-shrink-0 btn-lg-square rounded bg-primary text-dark me-3">
                                            <i class="fa fa-boxes-stacked fs-4"></i>
                                        </div>
                                        <h5 class="lh-base mb-0">
                                            Customized Packaging
                                        </h5>
                                    </div>
                                </div>

                                <div class="col-md-6 wow fadeIn" data-wow-delay="0.6s">
                                    <div class="d-flex align-items-center bg-light rounded h-100 p-4">
                                        <div class="flex-shrink-0 btn-lg-square rounded bg-primary text-dark me-3">
                                            <i class="fa fa-ship fs-4"></i>
                                        </div>
                                        <h5 class="lh-base mb-0">
                                            Global Export Logistics
                                        </h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 d-none d-xl-block">
                    <div class="position-relative h-100 wow fadeIn" data-wow-delay="0.5s">
                        <img class="img-fluid rounded w-100 h-100 mb-n4" style="object-fit: cover;"
                            src="img/feature2.jpg" alt="feature2">
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Features End -->


    <!-- Testimonial Start -->
    <div class="container-fluid bg-light py-5">
        <div class="container py-5">
            <div class="section-title wow fadeIn" data-wow-delay="0.1s">
                <h5 class="mb-3"><i class="fa fa-leaf text-primary me-2"></i>Testimonial</h5>
                <h1 class="display-5 mb-5">What Our Customers Say</h1>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                    <div class="bg-white rounded h-100 p-4">
                        <i class="fa fa-quote-left fa-5x text-primary mb-2"></i>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sollicitudin, nisl
                            libero id sapien. Nulla quis leo eu libero euismod sit amet sit amet sapien.</p>
                        <hr class="w-25 my-4">
                        <div class="d-flex">
                            <img class="flex-shrink-0 rounded" width="50" height="50" src="img/testimonial-1.jpg"
                                alt="">
                            <div class="ms-3">
                                <h5 class="mb-1">Client Name</h5>
                                <span>Profession</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.3s">
                    <div class="bg-white rounded h-100 p-4">
                        <i class="fa fa-quote-left fa-5x text-primary mb-2"></i>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sollicitudin, nisl
                            libero id sapien. Nulla quis leo eu libero euismod sit amet sit amet sapien.</p>
                        <hr class="w-25 my-4">
                        <div class="d-flex">
                            <img class="flex-shrink-0 rounded" width="50" height="50" src="img/testimonial-2.jpg"
                                alt="">
                            <div class="ms-3">
                                <h5 class="mb-1">Client Name</h5>
                                <span>Profession</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                    <div class="bg-white rounded h-100 p-4">
                        <i class="fa fa-quote-left fa-5x text-primary mb-2"></i>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sollicitudin, nisl
                            libero id sapien. Nulla quis leo eu libero euismod sit amet sit amet sapien.</p>
                        <hr class="w-25 my-4">
                        <div class="d-flex">
                            <img class="flex-shrink-0 rounded" width="50" height="50" src="img/testimonial-3.jpg"
                                alt="">
                            <div class="ms-3">
                                <h5 class="mb-1">Client Name</h5>
                                <span>Profession</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->


    <!-- Team Start -->
    <!-- <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="section-title wow fadeIn" data-wow-delay="0.1s">
                <h5 class="mb-3"><i class="fa fa-leaf text-primary me-2"></i>Our Team</h5>
                <h1 class="display-5 mb-5">Our Agriculture Experts</h1>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.1s">
                    <div class="team-item position-relative bg-light rounded overflow-hidden p-4">
                        <div class="position-relative overflow-hidden rounded-top">
                            <img class="img-fluid rounded-top w-100" src="img/team-1.jpg" alt="">
                            <div
                                class="team-social position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center">
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-x-twitter"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                        <div class="bg-white rounded-bottom text-center p-4">
                            <h5>James Anderson</h5>
                            <span>Farm Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.3s">
                    <div class="team-item position-relative bg-light rounded overflow-hidden p-4">
                        <div class="position-relative overflow-hidden rounded-top">
                            <img class="img-fluid rounded-top w-100" src="img/team-2.jpg" alt="">
                            <div
                                class="team-social position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center">
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-x-twitter"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                        <div class="bg-white rounded-bottom text-center p-4">
                            <h5>Michael Carter</h5>
                            <span>Agricultural Specialist</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.5s">
                    <div class="team-item position-relative bg-light rounded overflow-hidden p-4">
                        <div class="position-relative overflow-hidden rounded-top">
                            <img class="img-fluid rounded-top w-100" src="img/team-3.jpg" alt="">
                            <div
                                class="team-social position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center">
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-x-twitter"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                        <div class="bg-white rounded-bottom text-center p-4">
                            <h5>David Wilson</h5>
                            <span>Production Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xl-3 wow fadeIn" data-wow-delay="0.7s">
                    <div class="team-item position-relative bg-light rounded overflow-hidden p-4">
                        <div class="position-relative overflow-hidden rounded-top">
                            <img class="img-fluid rounded-top w-100" src="img/team-4.jpg" alt="">
                            <div
                                class="team-social position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center">
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-x-twitter"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                        <div class="bg-white rounded-bottom text-center p-4">
                            <h5>Robert Taylor</h5>
                            <span>Farming Consultant</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Team End -->


    <!-- Blog Start -->
    <!-- <div class="container-fluid bg-light py-5">
        <div class="container py-5">
            <div class="section-title wow fadeIn" data-wow-delay="0.1s">
                <h5 class="mb-3"><i class="fa fa-leaf text-primary me-2"></i>Blog Posts</h5>
                <h1 class="display-5 mb-5">Latest From the Farm</h1>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.1s">
                    <div class="blog-item position-relative overflow-hidden bg-white rounded h-100 p-4">
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <span>01 Jan 2045</span>
                            <hr class="mx-4">
                            <span>Design</span>
                        </div>
                        <a href="" class="h4 lh-base d-block text-center mb-4">How Sustainable Farming Protects
                            Future</a>
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid rounded w-100" src="img/blog-1.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.3s">
                    <div class="blog-item position-relative overflow-hidden bg-white rounded h-100 p-4">
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <span>01 Jan 2045</span>
                            <hr class="mx-4">
                            <span>Design</span>
                        </div>
                        <a href="" class="h4 lh-base d-block text-center mb-4">Essential Tips for Growing Healthy
                            Crops</a>
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid rounded w-100" src="img/blog-2.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 wow fadeIn" data-wow-delay="0.5s">
                    <div class="blog-item position-relative overflow-hidden bg-white rounded h-100 p-4">
                        <div class="d-flex align-items-center justify-content-center mb-2">
                            <span>01 Jan 2045</span>
                            <hr class="mx-4">
                            <span>Design</span>
                        </div>
                        <a href="" class="h4 lh-base d-block text-center mb-4">Best Practices for Successful Organic
                            Farming</a>
                        <div class="position-relative overflow-hidden rounded">
                            <img class="img-fluid rounded w-100" src="img/blog-3.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Blog End -->


    <?php include("components/indexComponents/footer.php"); ?>

    <?php include("components/indexComponents/script.php"); ?>

</body>

</html>