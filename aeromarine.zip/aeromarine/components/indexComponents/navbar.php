<!-- Spinner Start -->
<div id="spinner"
    class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex flex-column align-items-center justify-content-center">
    <span class="spinner-border text-primary mb-2" role="status" style="width: 3rem; height: 3rem;"></span>
    Loading...
</div>
<!-- Spinner End -->


<!-- Header Start -->

<nav class="navbar navbar-expand-lg navbar-light px-lg-5">
    <a href="index.php" class="navbar-brand ms-4 ms-lg-0 p-2">
        <div class="logo">
            <img class="img-fluid" src="img/logo.png" alt="logo"">
        </div>
    </a>
    <button type=" button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav mx-auto p-4 p-lg-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="" class="nav-item nav-link">About</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Product</a>
                        <!-- <div class="dropdown-menu overflow-hidden border-top border-5 border-dark mt-2">
                            <a href="blog.php" class="dropdown-item">Indian Turmeric Fingers</a>
                            <a href="feature.php" class="dropdown-item">Pure Turmeric Powder</a>
                            <a href="team.php" class="dropdown-item">Red Chilli Powder</a>
                            <a href="testimonial.php" class="dropdown-item">Dehydrated Garlic Powder</a>
                            <a href="404.php" class="dropdown-item">Dehydrated Onion Powder</a>
                            <a href="404.php" class="dropdown-item">Processed Psyllium Husk</a>
                            <a href="404.php" class="dropdown-item">Dehydrated Potato Powder</a>
                            <a href="404.php" class="dropdown-item">Natural Jaggery Cubes</a>
                            <a href="404.php" class="dropdown-item">Free-Flowing Jaggery Powder</a>
                        </div> -->

                        <div
                            class="dropdown-menu product-dropdown overflow-x-hidden border-top border-5 border-dark mt-2">

                            <h6 class="dropdown-header fw-bold text-dark">
                                Premium Spices & Dehydrated Powders
                            </h6>
                            <a href="" class="dropdown-item">Indian Turmeric Fingers</a>
                            <a href="" class="dropdown-item">Pure Turmeric Powder</a>
                            <a href="" class="dropdown-item">Red Chilli Powder</a>
                            <a href="" class="dropdown-item">Dehydrated Garlic Powder</a>
                            <a href="" class="dropdown-item">Dehydrated Onion Powder</a>

                            <h6 class="dropdown-header fw-bold text-dark">
                                Industrial & Functional Food Ingredients
                            </h6>
                            <a href="" class="dropdown-item">Processed Psyllium Husk</a>
                            <a href="" class="dropdown-item">Dehydrated Potato Powder</a>

                            <h6 class="dropdown-header fw-bold text-dark">
                                Traditional Sweeteners & Core Agro Products
                            </h6>
                            <a href="" class="dropdown-item">Natural Jaggery Cubes</a>
                            <a href="" class="dropdown-item">Free-Flowing Jaggery Powder</a>

                        </div>

                    </div>
                    <a href="service.php" class="nav-item nav-link">Certification</a>
                    <a href="service.php" class="nav-item nav-link">Gallery</a>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
                <!-- <a class="btn btn-primary btn-custom rounded-pill d-none d-lg-flex"
            href="https://htmlcodex.com/downloading/?item=4081">Pro Version</a> -->
            </div>
</nav>

<!-- Header End -->