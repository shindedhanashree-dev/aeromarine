    <!-- Footer Start -->
    <div class="container-fluid footer bg-dark text-light py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">About us</h4>
                    <p>Aeromarine Import Exports is an India-based agricultural export company specializing in premium
                        spices, dehydrated ingredients, psyllium husk, and natural sweeteners. We are committed to
                        quality, reliable sourcing, customized packaging, and seamless global trade.</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Quick Links</h4>
                    <a class="btn btn-link" href="index.php">Home</a>
                    <a class="btn btn-link" href="#">About Us</a>
                    <a class="btn btn-link" href="">Certification</a>
                    <a class="btn btn-link" href="">Gallery</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Our Office</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Address</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+91 9152331931</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>aeromarine20@gmail.com</p>
                    <div class="d-flex pt-3">
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-x-twitter"></i></a>
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-square btn-primary me-2" href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-4">Gallery</h4>
                    <div class="row g-2">
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service1.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service2.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service3.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/service4.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/carousel-1.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid rounded w-100" src="img/carousel-2.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Copyright Start -->
    <!-- <div class="container-fluid copyright bg-dark text-light py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; <a class="fw-semi-bold" href="#">Your Site Name</a>, All Right Reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                    Designed By <a class="fw-semi-bold" href="https://htmlcodex.com">HTML Codex</a>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Copyright Start -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top pt-2"><i class="bi bi-arrow-up"></i></a>

    <div class="sticky-buttons">
        <a href="tel:+919152331931" class="sticky-button">
            <img src="img/telephone.png" alt="telephone">
        </a>
        <a href="https://wa.me/919152331931/?text=Hi, I have query please Provide more details and arrange to callback"
            class="sticky-button">
            <img src="img/whatsapp.png" alt="whatsapp">
        </a>
        <!-- <a href="https://share.google/0PsKRqkBUwMOiObsf" class="sticky-button">
            <img src="img/gmb.png" alt="whatsapp">
        </a> -->
    </div>