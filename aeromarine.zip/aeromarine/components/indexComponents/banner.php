<div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="w-100" src="img/carousel-1.jpg" alt="carousel1">
            <div class="carousel-caption">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-10 col-md-8">

                        <h5 class="text-white mb-3 animated slideInDown">
                            <i class="fa fa-leaf text-primary me-2"></i>
                            Welcome to Aeromarine Import Exports
                        </h5>

                        <h4 class="display-4 text-white mb-5 animated slideInDown">
                            Connecting India's Finest Agro Products to the World
                        </h4>

                        <a href="about.php" class="btn btn-primary btn-custom rounded-pill animated slideInDown">
                            Discover Our Company
                        </a>

                    </div>
                </div>
            </div>
        </div>
        <div class="carousel-item">
            <img class="w-100" src="img/carousel-2.jpg" alt="carousel2">
            <div class="carousel-caption">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-10 col-md-8">
                        <h5 class="text-white mb-3 animated slideInDown">
                            <i class="fa fa-leaf text-primary me-2"></i>
                            Quality Ingredients. Global Opportunities.
                        </h5>

                        <h4 class="display-4 text-white mb-5 animated slideInDown">
                            Premium Spices & Dehydrated Ingredients
                        </h4>

                        <a href="products.php" class="btn btn-primary btn-custom rounded-pill animated slideInDown">
                            Explore Our Products
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>